public class Product {
    // Attributes
    int productId;
    String productName;
    double price;
    int quantityInStock;

    // Parameterized constructor
    public Product(int productId, String productName, double price, int quantityInStock) {
        this.productId = productId;
        this.productName = productName;
        this.price = price;
        this.quantityInStock = quantityInStock;
    }

    // Default constructor
    public Product() {
        this.productId = 0;
        this.productName = "";
        this.price = 0.0;
        this.quantityInStock = 0;
    }

    // Method to update quantity
    public void updateQuantity(int amountToAdd) {
        this.quantityInStock += amountToAdd;
        System.out.println("Stock updated for " + this.productName + ". New quantity: " + this.quantityInStock);
    }

    // Method to print product info
    public void printProductInfo() {
        System.out.println("ID: " + productId + " | Name: " + productName + " | Price: $" + price + " | Stock: " + quantityInStock);
    }

    public static void main(String[] args) {
        // Creating objects using both constructors
        Product p1 = new Product();
        Product p2 = new Product(101, "Mechanical Keyboard", 89.99, 15);

        System.out.println("--- Initial Info ---");
        p1.printProductInfo();
        p2.printProductInfo();

        System.out.println("\n--- Updating Stock ---");
        p1.productName = "Generic Mouse"; // Give it a name to make output clearer
        p1.updateQuantity(50);
        p2.updateQuantity(10);

        System.out.println("\n--- Final Info ---");
        p1.printProductInfo();
        p2.printProductInfo();
    }
}
