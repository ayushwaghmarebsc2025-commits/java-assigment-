public class Product {
    private String productId;
    private String productName;
    private double price;
    private int quantity;
    private static String storeName = "Default Mart";
    private static int totalProducts = 0;

    public Product(String productId, String productName, double price, int quantity) {
        this.productId = productId;
        this.productName = productName;
        this.price = price;
        this.quantity = quantity;
        totalProducts++;
    }

    public Product() {
        this("Unknown", "Unknown", 0.0, 0);
    }

    public static void setStoreName(String name) { storeName = name; }
    public static void printTotalProducts() { System.out.println("Total Product Types: " + totalProducts); }

    public void addStock(int amount) {
        if (amount > 0) quantity += amount;
    }

    public void sellProduct(int amount) {
        if (amount > 0 && amount <= quantity) quantity -= amount;
    }

    public void printProductDetails() {
        System.out.println("Store: " + storeName + " | ID: " + productId + " | Name: " + productName + " | Stock: " + quantity);
    }

    public static void printAllProducts(Product[] products) {
        for (Product p : products) {
            if (p != null) p.printProductDetails();
        }
    }

    public static void main(String[] args) {
        Product.setStoreName("Green Valley Grocers");
        Product p1 = new Product("P01", "Apples", 2.99, 50);
        Product p2 = new Product();
        p1.sellProduct(10);
        Product.printAllProducts(new Product[]{p1, p2});
        Product.printTotalProducts();
    }
}
