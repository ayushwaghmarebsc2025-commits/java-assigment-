public class Employee {
    private String employeeId;
    private String employeeName;
    private double salary;
    private static String companyName = "Default Corp";
    private static int employeeCount = 0;

    public Employee(String employeeId, String employeeName, double salary) {
        this.employeeId = employeeId;
        this.employeeName = employeeName;
        this.salary = salary;
        employeeCount++;
    }

    public Employee() {
        this("Unknown", "Unknown", 0.0);
    }

    public static void setCompanyName(String name) { companyName = name; }
    public static void printEmployeeCount() { System.out.println("Total Employees: " + employeeCount); }

    public void raiseSalary(double amount) {
        if (amount > 0) salary += amount;
    }

    public void printEmployeeDetails() {
        System.out.println("Company: " + companyName + " | ID: " + employeeId + " | Name: " + employeeName + " | Salary: $" + salary);
    }

    public static void printAllEmployees(Employee[] employees) {
        for (Employee emp : employees) {
            if (emp != null) emp.printEmployeeDetails();
        }
    }

    public static void main(String[] args) {
        Employee.setCompanyName("TechNova");
        Employee e1 = new Employee("E01", "Bruce Wayne", 85000);
        Employee e2 = new Employee();
        e1.raiseSalary(5000);
        Employee.printAllEmployees(new Employee[]{e1, e2});
        Employee.printEmployeeCount();
    }
}
