public class BankAccount {
    private String accountNumber;
    private String accountHolder;
    private double balance;
    private static String bankName = "Default Bank";

    public BankAccount(String accountNumber, String accountHolder, double balance) {
        this.accountNumber = accountNumber;
        this.accountHolder = accountHolder;
        this.balance = balance;
    }

    public BankAccount() {
        this("Unknown", "Unknown", 0.0);
    }

    public static void setBankName(String name) { bankName = name; }

    public void deposit(double amount) {
        if (amount > 0) { balance += amount; }
    }

    public void withdraw(double amount) {
        if (amount > 0 && amount <= balance) { balance -= amount; }
    }

    public void printAccountDetails() {
        System.out.println("Bank: " + bankName + " | Acc: " + accountNumber + " | Holder: " + accountHolder + " | Bal: $" + balance);
    }

    public static void main(String[] args) {
        BankAccount.setBankName("Apex Global Bank");
        BankAccount acc1 = new BankAccount("ACC1001", "Alice Johnson", 1500.0);
        BankAccount acc2 = new BankAccount();
        acc1.deposit(500);
        acc1.printAccountDetails();
        acc2.printAccountDetails();
    }
}
