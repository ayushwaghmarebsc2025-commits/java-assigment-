public class InventoryItem {
    // Static variable to track total items across all objects
    private static int totalItems = 0;

    // Instance variables
    private String itemName;
    private int quantity;

    // Constructor
    public InventoryItem(String itemName, int quantity) {
        this.itemName = itemName;
        this.quantity = quantity;
        totalItems += quantity; // Add the initial quantity to the total
    }

    // Static method
    public static int getTotalItems() {
        return totalItems;
    }

    // Instance methods
    public void addToInventory(int amount) {
        if (amount > 0) {
            this.quantity += amount;
            totalItems += amount;
            System.out.println(amount + " added to " + this.itemName + ".");
        }
    }

    public void removeFromInventory(int amount) {
        if (amount > 0 && amount <= this.quantity) {
            this.quantity -= amount;
            totalItems -= amount;
            System.out.println(amount + " removed from " + this.itemName + ".");
        } else {
            System.out.println("Insufficient stock to remove " + amount + " from " + this.itemName + ".");
        }
    }

    public void displayItemDetails() {
        System.out.println("Item: " + this.itemName + " | Stock: " + this.quantity);
    }
}
