public class Main {
    public static void main(String[] args) {
        System.out.println("--- Store Inventory System ---");
        
        // Initializing Total Items
        System.out.println("Initial Total Items in Stock: " + InventoryItem.getTotalItems());

        // Creating instances
        InventoryItem item1 = new InventoryItem("Laptops", 50);
        InventoryItem item2 = new InventoryItem("Smartphones", 150);
        InventoryItem item3 = new InventoryItem("Headphones", 80);

        System.out.println("\nAfter adding initial products:");
        item1.displayItemDetails();
        item2.displayItemDetails();
        item3.displayItemDetails();
        System.out.println("Total Items in Stock: " + InventoryItem.getTotalItems());

        System.out.println("\n--- Updating Inventory ---");
        item1.addToInventory(20);
        item2.removeFromInventory(30);
        item3.addToInventory(10);
        item3.removeFromInventory(100); // Should trigger insufficient stock

        System.out.println("\n--- Final Inventory ---");
        item1.displayItemDetails();
        item2.displayItemDetails();
        item3.displayItemDetails();
        System.out.println("Final Total Items in Stock: " + InventoryItem.getTotalItems());
    }
}
